package org.agileindia.mathworks;

public interface Condition {
    boolean isSatisfiedBy(int number);
}

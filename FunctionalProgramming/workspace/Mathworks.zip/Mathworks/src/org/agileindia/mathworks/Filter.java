package org.agileindia.mathworks;

import java.util.ArrayList;
import java.util.List;

public class Filter {
    public static Condition ODD = new Odd();
    public static Condition PRIME = new Prime();

    public static List<Integer> select(List<Integer> numbers, Condition condition) {
        List<Integer> selected = new ArrayList<Integer>();
        for (Integer number : numbers) {
            if (condition.isSatisfiedBy(number)) {
                selected.add(number);
            }
        }
        return selected;
    }

}
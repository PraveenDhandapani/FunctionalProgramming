package org.agileindia.mathworks;

public class Odd implements Condition {
    public boolean isSatisfiedBy(int number) {
        if (number % 2 == 0) {
            return false;
        }
        return true;
    }
}
